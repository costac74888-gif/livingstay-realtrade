# 생숙실거래 — Replit 설치/실행 가이드 (전국 발굴 + 안정화 버전)

## ⚠️ Replit Agent에게 그대로 전달할 프롬프트

이번에도 Replit 쪽에 이미 수동으로 고친 부분(env 키, buildingType/buildingUse 필드명,
JUSO 괄호 제거, verify_units 청크 구조 등)이 있을 수 있으니 아래 프롬프트를 그대로 붙여서
diff 병합을 시키는 걸 추천합니다.

```
첨부한 파일들은 Claude가 만든 업데이트본이야. 아래 순서로 진행해줘.

1. 각 파일을 지금 프로젝트의 같은 파일과 diff 비교해줘.
2. 이미 우리가 고쳐둔 게 있으면(예: os.environ 읽기, buildingType/buildingUse 필드명,
   JUSO 괄호 제거, verify_units의 청크+증분커밋 구조) 그건 유지해줘.
3. 이번에 새로 추가된 것들은 반영해줘:
   - db.py: raw_key DB 레벨 UNIQUE 제약 자동 부여(_ensure_raw_key_unique_constraint),
     master_buildings.source 컬럼
   - app.py: /api/favorites 엔드포인트 (관심단지 200건 제한 해제)
   - static/index.html: 관심단지 조회가 /api/favorites 쓰도록 수정
   - address_utils.py: BjdongMap.all_sgg_codes(), sgg_text() 추가
   - discover_new_buildings.py: 전국 시군구 대상 신규 생숙 발굴 배치 (신규 파일)
   - verify_units.py: 30실 게이트 제거, getBrTitleInfo 기반 생활숙박시설 용도 판정으로 변경
4. python db.py 실행해서 유니크 제약이 잘 걸리는지, 기존 데이터(마스터/실거래)가
   안 없어졌는지 확인해줘.
5. 끝나면 뭘 유지했고 뭘 새로 추가했는지 요약해줘.
```

## 1. 이번 업데이트 요약

| 구분 | 내용 |
|---|---|
| 데이터 안정성 | `raw_key`에 DB 레벨 UNIQUE 제약 자동 적용 (중복 사전 정리 후 부여, 안전) |
| 관심단지 | `/api/favorites` 신규 — 200건 제한 없이 정확히 조회 |
| 등록 기준 변경 | 30실 이상 게이트 제거 → "건축HUB 표제부 + 생활숙박시설 용도 확인"만으로 등록, 호실 수는 정보로만 표시 |
| 전국 발굴 | `discover_new_buildings.py` 신규 — 마스터파일에 없는 지역까지 전국 시군구를 훑어 신규 생숙 자동 등록 |

## 2. 실행 순서 (처음 세팅이든 업데이트든 이 순서)

```bash
pip install -r requirements.txt --break-system-packages

python db.py                    # 컬럼/제약 보강 (기존 데이터 보존)
python migrate_regions.py       # 기존 실거래에 si_do/sgg_nm 백필 (이미 했으면 스킵됨)
python load_master.py "생활숙박시설현황....xlsx"   # 최초 1회, 이미 했으면 스킵

python app.py                   # 서버 실행
```

## 3. 전국 조회가 가능해지는 단계 — 두 배치를 구분해서 운영

### ① 가격 갱신 배치 (마스터에 "있는" 건물만, 매일)
```bash
python sync_batch.py --months 3
```

### ② 신규 발굴 배치 (마스터에 "없는" 지역까지 전국, 월 1회 권장)
전국 시군구가 몇 개인지 먼저 확인:
```bash
python discover_new_buildings.py --list-only
```
그 다음 **20~30개씩 나눠서** 여러 번 실행 (한 번에 다 돌리면 실행환경 특성상 끊길 수 있음):
```bash
python discover_new_buildings.py --region-offset 0   --region-limit 30 --months 3
python discover_new_buildings.py --region-offset 30  --region-limit 30 --months 3
python discover_new_buildings.py --region-offset 60  --region-limit 30 --months 3
# ... 전체 시군구 수만큼 offset을 늘려가며 반복
```
- 이미 처리한 (시군구, 계약월) 조합은 `discover_progress` 테이블에 기록되어 **재실행해도 중복 조회 안 함** — 중간에 끊겨도 이어서 실행 가능
- 신규 발굴된 건물은 `master_buildings.source = 'api_discovered'`로 표시되어 원본 마스터파일 항목과 구분됨
- 등록 기준은 호실 수와 무관 — 건축HUB가 "생활숙박시설"로 확인해주는 건물이면 전부 등록되고, 호실 수는 참고 정보로만 저장

### ③ 매일 자동 갱신 (Scheduled Deployments)
```bash
python sync_batch.py --months 3          # 매일
python discover_new_buildings.py --region-offset 0 --region-limit 250 --months 1   # 월 1회
```

## 4. 사전 준비물 (Secrets)
| Key | 발급처 |
|---|---|
| `RTMS_SERVICE_KEY` | data.go.kr |
| `BLD_SERVICE_KEY` | data.go.kr (동일 키) |
| `JUSO_API_KEY` | juso.go.kr |

법정동코드 전체자료 CSV(code.go.kr, 무료)도 프로젝트 루트에 있어야 합니다 —
`discover_new_buildings.py`가 전국 시군구 목록을 여기서 뽑아옵니다.

## 5. 동작 확인
- `GET /api/health` — 마지막 배치 실행 시각/건수
- `GET /api/favorites?keys=건물명|주소` — 관심단지 조회 확인
- `discover_new_buildings.py --list-only` — 전국 시군구 개수 확인



