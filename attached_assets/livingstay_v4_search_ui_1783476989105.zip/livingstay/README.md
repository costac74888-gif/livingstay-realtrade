# 생숙실거래 — Replit 설치/실행 가이드 (PostgreSQL 버전)

## ⚠️ 화면 개편 반영 시 꼭 먼저 할 것 (기존 76건 데이터 보존)

이번에 표 형식 + 시/군/구 계층검색 + 기간필터 + 관심단지로 화면을 바꾸면서
`transactions` 테이블에 `si_do`, `sgg_nm` 컬럼이 추가되었습니다.
**이미 쌓인 데이터가 있다면 아래 순서로 한 번 실행**해야 시/군/구 검색이 과거 데이터에도 적용됩니다.

```bash
python db.py               # 1) 컬럼 추가 (ALTER TABLE, 기존 데이터 안 지워짐)
python migrate_regions.py  # 2) 기존 76건에 si_do/sgg_nm 백필
```

이후 새로 도는 `sync_batch.py`는 자동으로 si_do/sgg_nm까지 채워 저장합니다.
(코드 위에 그대로 덮어써도 안전 — CREATE TABLE IF NOT EXISTS + ALTER TABLE ADD COLUMN IF NOT EXISTS 방식이라
기존 305/337건 마스터, 76건 실거래 데이터는 그대로 유지됩니다.)

## 1. Replit에서 PostgreSQL 데이터베이스 먼저 생성
왼쪽 메뉴에서 **"Database"** 탭 클릭 → **"Create a database"** → **PostgreSQL** 선택.
생성되면 `DATABASE_URL` 이라는 Secret이 **자동으로** 등록됩니다.

## 2. 그 외 필요한 Secrets
| Key | Value |
|---|---|
| `RTMS_SERVICE_KEY` | data.go.kr 발급키 |
| `BLD_SERVICE_KEY` | 같은 data.go.kr 키 |
| `JUSO_API_KEY` | juso.go.kr 승인키 |

## 3. 법정동코드 CSV
code.go.kr "법정동코드 전체자료" 다운로드 → 프로젝트 루트에 저장

## 4. 설치
```bash
pip install -r requirements.txt --break-system-packages
```

## 5. 실행 순서
```bash
python db.py                    # 테이블 생성/컬럼 보강
python migrate_regions.py       # 기존 데이터 있으면 백필 (최초 1회)
python load_master.py "생활숙박시설현황....xlsx"   # 30실 이상만 적재
python sync_batch.py --months 3 # 지역 단위(--region 등)로 나눠 실행 권장
python app.py                   # 서버 실행
```

## 6. 새 화면에서 바뀐 것
- **표 형식** — 카드 대신 건물명/주소/면적/거래금액/계약일/거래유형을 한 줄씩 나열
- **시/도 → 시/군/구 → 읍/면/동 계층 검색** — `/api/regions`가 트리 구조로 응답, 프론트에서 순차 드롭다운 구성
- **기간 필터** — `/api/years`로 실제 존재하는 연도만 옵션에 노출, 기본값 올해
- **관심단지** — 로그인 없이 브라우저 `localStorage`에 저장(기기별로 따로 저장됨). 나중에 여러 기기에서 동기화하려면 로그인 붙여서 서버 저장(B안)으로 전환 가능
- **홈스퀘어부동산 로고** — 간단한 하우스+체크 마크 SVG로 표시. 실제 로고 파일이 있으면 `<svg class="brand-mark">...` 부분을 `<img src="logo.png" class="brand-mark">`로 교체

## 7. 매일 자동 갱신
Replit **Scheduled Deployments**에 등록:
```bash
python sync_batch.py --months 3
```

## 8. 동작 확인
- `GET /api/health` — 마지막 배치 실행 시각/건수
- `GET /api/regions` — 계층 트리 확인
- `GET /api/years` — 연도 목록 확인
- `GET /api/transactions?si_do=경기도&sgg_nm=수원시&year=2026` — 계층 검색 확인


