# -*- coding: utf-8 -*-
"""
building_registry.py — "이 건물이 진짜 생활숙박시설인가"를 판별하는 로직을 한 곳에 모은 공용 모듈.

배경
------------------------------------------------------------
건축HUB 표제부(getBrTitleInfo)의 주용도/기타용도 필드는 건물마다 표기가 들쭉날쭉하다.
- 어떤 건물(경희마크329)은 "숙박시설(생활숙박시설)"처럼 친절하게 괄호로 표기
- 어떤 건물(휘닉스파크레드앤핑크콘도미니엄)은 그냥 "숙박시설"(주용도)뿐이고,
  실제로는 "휴양콘도미니엄"(층별 용도)이라 생숙이 아님
- 어떤 건물(휴스테이 등)은 표제부엔 표기가 없지만 층별개요엔 "생활숙박시설"로 명확히 나옴

그래서 표제부 하나만 보고 판정하면 안 되고, 아래 순서로 확인해야 정확하다.
  1) 표제부 주용도/기타용도에 "생활숙박시설"이 있으면 즉시 확정 (API 호출 절약)
  2) 없으면 층별개요(getBrFlrOulnInfo)를 추가 조회해서, 각 층 용도에
     "생활숙박시설"이 하나라도 있는지 확인
  3) 층별개요에도 없으면(예: "휴양콘도미니엄"만 있음) → 생숙 아님으로 최종 판정

discover_new_buildings.py, verify_units.py, sync_batch.py 전부 반드시 이 모듈의
함수만 사용해야 한다 — 각 파일에 판정 로직을 따로 구현하면 이번처럼 한쪽만
고쳐지고 한쪽은 옛 기준(30실 게이트, 검증 없는 통과 등)으로 남는 문제가 반복된다.
"""

import os
import time
from xml.etree import ElementTree as ET

import requests

BLD_SERVICE_KEY = os.environ["BLD_SERVICE_KEY"]
BLD_TITLE_URL = "https://apis.data.go.kr/1613000/BldRgstHubService/getBrTitleInfo"
BLD_FLOOR_URL = "https://apis.data.go.kr/1613000/BldRgstHubService/getBrFlrOulnInfo"

REQUEST_SLEEP = 0.15
LIVINGSTAY_KEYWORD = "생활숙박시설"


def fetch_building_title(sigungu_cd: str, bjdong_cd: str, plat_gb: str, bun: str, ji: str):
    """표제부(getBrTitleInfo) 조회 → dict 또는 None (결과 없음)"""
    params = {
        "serviceKey": BLD_SERVICE_KEY,
        "sigunguCd": sigungu_cd,
        "bjdongCd": bjdong_cd,
        "platGbCd": plat_gb,
        "bun": bun.zfill(4),
        "ji": ji.zfill(4),
        "numOfRows": 5,
        "pageNo": 1,
    }
    resp = requests.get(BLD_TITLE_URL, params=params, timeout=15)
    resp.raise_for_status()
    root = ET.fromstring(resp.content)
    items = root.findall(".//item")
    if not items:
        return None
    row = {child.tag: (child.text or "").strip() for child in items[0]}
    return {
        "bld_nm": row.get("bldNm", "").strip(),
        "ho_cnt": int(row.get("hoCnt", 0) or 0),
        "main_purps": row.get("mainPurpsCdNm", ""),
        "etc_purps": row.get("etcPurps", ""),
        "new_plat_plc": row.get("newPlatPlc", "").strip(),
        "plat_plc": row.get("platPlc", "").strip(),
    }


def fetch_floor_outline(sigungu_cd: str, bjdong_cd: str, plat_gb: str, bun: str, ji: str):
    """층별개요(getBrFlrOulnInfo) 조회 → 각 층의 주용도/상세용도 리스트. 실패 시 None(조회실패, '없음'과 구분)."""
    params = {
        "serviceKey": BLD_SERVICE_KEY,
        "sigunguCd": sigungu_cd,
        "bjdongCd": bjdong_cd,
        "platGbCd": plat_gb,
        "bun": bun.zfill(4),
        "ji": ji.zfill(4),
        "numOfRows": 100,
        "pageNo": 1,
    }
    try:
        resp = requests.get(BLD_FLOOR_URL, params=params, timeout=15)
        resp.raise_for_status()
    except Exception:
        return None  # 조회 자체 실패 — "생숙 아님"과 구분해서 나중에 재시도 가능하게 함

    root = ET.fromstring(resp.content)
    items = root.findall(".//item")
    floors = []
    for item in items:
        row = {child.tag: (child.text or "").strip() for child in item}
        floors.append({
            "flr_gb_nm": row.get("flrGbCdNm", ""),
            "flr_no_nm": row.get("flrNoNm", ""),
            "main_purps": row.get("mainPurpsCdNm", ""),
            "etc_purps": row.get("etcPurps", ""),
        })
    return floors


def _find_categories(text: str) -> set:
    """텍스트 안에 생활/콘도/호텔 키워드가 각각 있는지 집합으로 반환 (동시에 여러 개 가능)"""
    found = set()
    if "생활숙박시설" in text:
        found.add("생활")
    if "휴양콘도미니엄" in text:
        found.add("콘도")
    # "관광숙박시설"(건축법 표준 용도명)과 "관광호텔"(실무에서 더 흔히 쓰는 표기) 둘 다 확인
    if "관광숙박시설" in text or "관광호텔" in text or "일반숙박시설" in text:
        found.add("호텔")
    return found


_CATEGORY_ORDER = ["생활", "호텔", "콘도"]  # 병기할 때 항상 이 순서로 표기 (예: "호텔·콘도")


def _combine_labels(categories: set) -> str:
    """카테고리 집합을 '호텔·콘도'처럼 정해진 순서로 병기한 문자열로 만든다.
    '혼재'라는 뭉뚱그린 표현 대신, 실제 해당하는 라벨을 그대로 보여주기 위함."""
    ordered = [c for c in _CATEGORY_ORDER if c in categories]
    return "·".join(ordered)


def classify_lodging_type(sigungu_cd: str, bjdong_cd: str, plat_gb: str, bun: str, ji: str):
    """
    이 지번의 건물을 생활/호텔/콘도 중 하나 또는 여러 개의 병기 라벨로 분류한다
    (표제부 → 필요시 층별개요 순).

    한 건물(또는 여러 층 전체)에 2가지 이상의 카테고리가 동시에 발견되면
    "혼재" 같은 뭉뚱그린 표현 대신 "호텔·콘도"처럼 실제 해당 라벨을 그대로
    병기한다 — 표제부 기타용도에 "관광호텔,휴양콘도미니엄"이 나란히 적힌 경우
    (빌라쥬 드 아난티류), 또는 층마다 다른 용도가 섞인 경우(하워드존슨 10층류) 등.

    반환값: (label, detail, title정보 dict 또는 None, 판정근거)
      label: '생활' | '호텔' | '콘도' | '호텔·콘도' | '생활·호텔' 등 병기 조합 | None(판정불가)
      detail: 건축물대장에 실제로 적힌 원문 표기 — 화면에 근거로 그대로 보여주는 용도.
    """
    title = fetch_building_title(sigungu_cd, bjdong_cd, plat_gb, bun, ji)
    time.sleep(REQUEST_SLEEP)

    if title is None:
        return None, "", None, "표제부 없음(일반건축물 추정)"

    combined = f"{title['main_purps']} {title['etc_purps']}".strip()
    categories = _find_categories(combined)

    if len(categories) == 1:
        return categories.pop(), combined, title, "표제부에서 확인"
    if len(categories) > 1:
        return _combine_labels(categories), combined, title, "표제부 안에 2가지 이상 용도 동시 표기"

    # 표제부만으론 판정 안 됨 → 층별개요 추가 조회, 전체 층을 훑어 카테고리 집합을 모은다
    floors = fetch_floor_outline(sigungu_cd, bjdong_cd, plat_gb, bun, ji)
    time.sleep(REQUEST_SLEEP)

    if floors is None:
        return None, combined, title, "층별개요 조회 실패(재시도 필요)"

    floor_detail_parts = []
    all_categories = set()
    for f in floors:
        floor_text = f"{f['main_purps']} {f['etc_purps']}".strip()
        if floor_text:
            floor_detail_parts.append(floor_text)
        all_categories |= _find_categories(floor_text)

    full_detail = (combined + " / " + " / ".join(sorted(set(floor_detail_parts)))).strip(" /")

    if len(all_categories) == 1:
        return all_categories.pop(), full_detail, title, "층별개요에서 확인"
    if len(all_categories) > 1:
        return _combine_labels(all_categories), full_detail, title, "층별개요에 여러 용도가 섞여 있음"

    return None, full_detail, title, "표제부·층별개요 모두 판정 불가(용도 표기 없음)"


def is_living_stay(sigungu_cd: str, bjdong_cd: str, plat_gb: str, bun: str, ji: str):
    """하위호환용 — classify_lodging_type()을 감싸서 예전처럼 True/False/None만 반환.
    새로 짜는 코드는 classify_lodging_type()을 직접 쓰는 걸 권장."""
    label, detail, title, reason = classify_lodging_type(sigungu_cd, bjdong_cd, plat_gb, bun, ji)
    if label == "생활":
        return True, title, reason
    if label:  # '호텔', '콘도', 또는 '호텔·콘도' 같은 병기 라벨 전부 False
        return False, title, reason
    return None, title, reason
