# 홈앤스테이 — 전국숙박시설실거래가조회 (최종 통합본)

이 zip 하나에 지금까지의 모든 결정사항이 반영되어 있습니다. 처음 세팅하시는
경우와, 이미 돌아가는 프로젝트에 통째로 업데이트하시는 경우 둘 다 아래 순서를
따르면 됩니다.

## 이 버전에 들어있는 것 (전체 목록)

**데이터 파이프라인**
- `load_master.py` — 첨부 마스터 엑셀 적재 (30실 게이트 제거됨, 옵션으로만 남음)
- `sync_batch.py` — 마스터에 있는 건물의 최신 실거래 갱신 (매일 실행용)
- `discover_new_buildings.py` — 전국 256개 시군구 대상 신규 건물 발굴 (월 1회 권장)
- `verify_units.py` — 호수 미기재로 제외됐던 건물 재검증
- `reclassify_buildings.py` — 기존 건물을 생활/호텔/콘도/혼재로 재분류 (삭제 아님)
- `backfill_address.py` — 기존 실거래에 시/도 정보 누락분 일괄 채움
- `building_registry.py` — **모든 용도 판정 로직이 여기 하나로 통일됨**
  (`classify_lodging_type()`: 표제부→층별개요 순으로 생활/호텔/콘도/혼재 판정)

**핵심 원칙 (전 스크립트 공통)**
1. 등록 기준은 호실 수가 아니라 "건축물대장으로 확인된 용도"
2. 생숙만 등록하는 게 아니라 생활/호텔/콘도/혼재 전부 등록 (화면 기본 필터가 "생숙만"일 뿐)
3. 같은 지번·같은 날짜·같은 가격으로 여러 호실이 거래돼도 raw_key에 층+발생순번이
   들어가 있어 뭉개지지 않음
4. si_do/sgg_nm은 항상 sgg_cd 하나로 계산 (마스터 파싱에 의존하지 않음)
5. 사용자가 뭘 제안하든(신규 추가/용도 정정 요청) **반드시 API로 재검증한 결과만 반영**

**백엔드 (`app.py`)**
- `GET /api/transactions` — si_do/sgg_nm/umd_nm/q/year/lodging_type 필터 + 페이지네이션
- `GET /api/regions` — 시/도>시/군구>읍/면동 계층 트리
- `GET /api/years` — 실제 데이터 연도 + 항상 최근 3년 기본 포함 (과거 연도 안 사라짐)
- `GET /api/favorites` — 관심단지 건수 제한 없이 정확히 조회
- `POST /api/submit-building` — 사용자가 새 건물 주소 제출 → 실시간 재검증 후 등록
- `POST /api/request-correction` — 기존 건물 용도 라벨 정정 요청 → 재검증 후 반영
- `GET /api/health` — 배치 마지막 실행 시각/건수

**화면 (`static/index.html`)**
- 브랜드: 홈앤스테이 / 타이틀: 전국숙박시설실거래가조회
- 시/도·시/군구·읍/면동 계층 검색 + 건물명/주소 텍스트 검색
- 용도 필터: 전체(맨 위) / 생숙만(기본 선택) / 호텔만 / 콘도만 / 혼재 건물만
- 검색기간(연도) 필터
- 표 형식: 건물명(용도 배지, 클릭시 정정요청) / 주소(시도 포함) / 면적 / 층 / 거래금액(만원, 콤마) / 계약일 / 거래유형
- 관심단지: localStorage 저장, 기본 5개(？admin=1이면 50개), 칩으로 상시 표시
- "+ 내 건물 추가 요청" 버튼 — 예상 용도 선택 가능하나 실제 반영은 재검증 결과만

## 설치 순서 (최초 세팅)

```bash
pip install -r requirements.txt --break-system-packages
```

### Secrets (Replit Database 탭에서 PostgreSQL 먼저 생성 → DATABASE_URL 자동 등록)
| Key | 발급처 |
|---|---|
| RTMS_SERVICE_KEY | data.go.kr |
| BLD_SERVICE_KEY | data.go.kr (동일 키) |
| JUSO_API_KEY | juso.go.kr |

### 법정동코드 파일
code.go.kr에서 "법정동코드 전체자료" 다운로드(zip 그대로 둬도 됨, 자동 압축해제) →
프로젝트 루트에 두고 `BJDONG_CODE_CSV` 환경변수로 경로 지정.

### 실행
```bash
python db.py                          # 전체 스키마 생성/보강 (기존 데이터 항상 보존)
python load_master.py "생활숙박시설현황....xlsx"
python backfill_address.py --dry-run  # 있으면 실행, 없으면 건너뜀
python backfill_address.py
python reclassify_buildings.py --dry-run
python reclassify_buildings.py
python sync_batch.py --months 3
python discover_new_buildings.py --list-only
python discover_new_buildings.py --region-offset 0 --region-limit 30 --months 3
# ... region-offset을 늘려가며 전체 반복
python app.py
```

## 이미 돌아가는 프로젝트에 업데이트하는 경우

이미 손으로 고친 부분(env 키, 필드명, 청크 구조 등)이 있을 수 있으니, 아래
Replit 프롬프트를 그대로 사용해 diff 병합을 시키는 걸 권장합니다.
README 하단 "Replit에 줄 프롬프트" 참고.

## 매일/월간 자동화 (Scheduled Deployments)
```bash
python sync_batch.py --months 3                                     # 매일
python discover_new_buildings.py --region-offset 0 --region-limit 256 --months 1   # 월 1회
```
